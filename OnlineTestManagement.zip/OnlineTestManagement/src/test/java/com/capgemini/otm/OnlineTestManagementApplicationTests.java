package com.capgemini.otm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineTestManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
