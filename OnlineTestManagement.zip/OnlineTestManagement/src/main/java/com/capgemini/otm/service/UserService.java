package com.capgemini.otm.service;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import com.capgemini.otm.entity.Login;
import com.capgemini.otm.entity.Question;
import com.capgemini.otm.entity.Test;
import com.capgemini.otm.entity.User;


public interface UserService {
	
	public String addUser(User user);
	
	public User login(Login login);
	
	public Question addQuestion(Question question,String token);

	public List<Question> getTest(String subject, String difficultyLevel,String token);
	
	public Set<Question> takeTest(String subject,String level,String token);
	
	public String addTest(Test test);

//	public Set<Question> questions(String header, String subject, String difficultyLevel);

	List<Test> getTests();

	public Set<Question> viewTest(int testId);

	public List<Question> showQuestionList();

	public String deleteQuestion(int qId);

	public User updateUser(int testId, String header);


}
