package com.capgemini.otm.serviceImpl;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.otm.entity.Login;
import com.capgemini.otm.entity.McqOptions;
import com.capgemini.otm.entity.Question;
import com.capgemini.otm.entity.Test;
import com.capgemini.otm.entity.User;
import com.capgemini.otm.repository.McqOptionsRepo;
import com.capgemini.otm.repository.QuestionRepo;
import com.capgemini.otm.repository.TestRepo;
import com.capgemini.otm.repository.UserRepo;
import com.capgemini.otm.service.UserService;
import com.capgemini.otm.util.JwtUtil;

import ExceptionHandler.UserException;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private QuestionRepo qRepo;

	@Autowired
	private TestRepo tRepo;

	@Autowired
	private McqOptionsRepo optionRepo;

	@Autowired
	private JwtUtil utility;

	@Override
	public String addUser(User user) {
		try {
			Optional<User> users = userRepo.findByEmail(user.getEmail());

			if (users.isPresent()) {
				throw new UserException(500, "user is already present", users.get().getEmail());

			} else {
				userRepo.save(user);
				return "user added Successfully";
			}

		} catch (Exception ex) {
			ex.getMessage();
			return "user is already present";
		}
	}

	@Override
	public User login(Login login) {
		
		return userRepo.findByEmailAndPassword(login.getEmail(), login.getPassword()).get();
		
	}
//	@Override
//	public String login(Login login, HttpServletResponse response) {
//		try {
//			Optional<User> user = userRepo.findByEmailAndPassword(login.getEmail(), login.getPassword());
//			if (user.isPresent()) {
//				String token = utility.generatetoken(user.get().getUserId());
//				response.setHeader("token", token);
//				response.addHeader("Access-Control-Allow-Headers", "*");
//				response.addHeader("Access-Control-Expose-Headers", "*");
//				System.out.println(token);
//				return "Login Sucessfully";
//			} else {
//				throw new UserException(500, "Invalid Credientials", login.getEmail());
//
//			}
//		} catch (Exception ex) {
//			ex.getMessage();
//			// ex.printStackTrace();
//			return "Invalid";
//		}
//	}

	@Override
	public Question addQuestion(Question question, String token) {
		int userId = utility.decodetoken(token);
		Optional<User> user = userRepo.findByUserId(userId);

		if (user.get().getType() == 1) {
			qRepo.save(question);
			Set<McqOptions> options = new HashSet<>();
			options = question.getOptions();

			System.out.println("hiii" + options);

			for (McqOptions mcqOptions : options) {
				mcqOptions.setQuestionId(question);

				optionRepo.save(mcqOptions);
				System.out.println(mcqOptions);
			}

			// Iterator<McqOptions> itr=options.iterator();
			// while(itr.hasNext()) {
			// McqOptions option=itr.next();
			// option.setQuestionId(question);
			// optionRepo.save(option);
			// System.out.println(option);
			// }
			return question;
		}
		return null;
	}

	@Override
	public List<Question> getTest(String subject, String difficultyLevel, String token) {
		int userId = utility.decodetoken(token);
		Optional<User> user = userRepo.findByUserId(userId);
		if (user.get().getType() == 0) {
			List<Test> tests = user.get().getTests();
			System.out.println(tests);
			List<Test> test = tRepo.findBySubjectAndDifficultyLevel(subject, difficultyLevel);
			test.removeAll(tests);

			System.out.println(test);
			return Lists.newArrayList(test.get(0).getQuestions());
		}
		return null;
	}

	@Override
	public Set<Question> takeTest(String subject, String level, String token) {
		int userId = utility.decodetoken(token);
		Optional<User> user = userRepo.findByUserId(userId);
		System.out.println(user.get().getUserId());
		if (user.get().getType() == 0) {
			List<Test> test = tRepo.findBySubjectAndDifficultyLevel(subject, level);
			System.out.println(test);
			return test.get(0).getQuestions();
		}
		return null;
	}

	@Override
	public String addTest(Test test) {
		List<Question> list = qRepo.findBySubjectAndDifficultyLevel(test.getSubject(), test.getDifficultyLevel());
		tRepo.save(test);
		Set<Question> questions = new HashSet<Question>();
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getTestId() == null) {
				list.get(i).setTestId(test);
				qRepo.save(list.get(i));
				questions.add(list.get(i));
			}
		}

		test.setQuestions(questions);
		tRepo.save(test);
		return "Added Sucessfully";
	}

	@Override
	public List<Test> getTests() {
		List<Test> list = tRepo.findAll();
		return list;

	}

	@Override
	public Set<Question> viewTest(int testId) {
		Optional<Test> tests = tRepo.findByTestId(testId);
		Set<Question> questions = tests.get().getQuestions();
		System.out.println(questions);

		return questions;
	}

	@Override
	public List<Question> showQuestionList() {
		List<Question> questionList = qRepo.findAll();
		return questionList;
	}

	@Override
	public String deleteQuestion(int qId) {
		Question question = qRepo.findByQuestionId(qId);

		System.out.println(question.getQuestionId());
		qRepo.delete(question);

		return "Deleted Sucessfully";
	}

	public Test Example(Test test, String token) {
		int userId = utility.decodetoken(token);
		Optional<User> user = userRepo.findByUserId(userId);
		if (user.get().getType() == 1) {
			tRepo.save(test);
			Set<Question> questions = new HashSet<>();
			questions = test.getQuestions();

			System.out.println("hiii" + questions);

			for (Question question : questions) {
				question.setTestId(test);
				question.setDifficultyLevel(test.getDifficultyLevel());
				question.setSubject(test.getSubject());
				addQuestion(question, token);
				qRepo.save(question);
				System.out.println(question);
			}
			return test;

		}
		return test;

	}

	@Override
	public User updateUser(int testId, String token) {
		int userId = utility.decodetoken(token);
		Optional<User> user = userRepo.findByUserId(userId);
		List<Test> tests = user.get().getTests();
		tests.add(tRepo.findByTestId(testId).get());
		return user.get();
	}

}
