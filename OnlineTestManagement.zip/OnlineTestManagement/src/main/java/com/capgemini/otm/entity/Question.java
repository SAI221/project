package com.capgemini.otm.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Question{
		
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int questionId;

@Column(unique=true)
private String question;

private String subject;
private String difficultyLevel;

@OneToMany(mappedBy="questionId")
private Set<McqOptions> options;

@ManyToOne @JsonIgnore
	private Test testId;
	
	
	
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getDifficultyLevel() {
		return difficultyLevel;
	}
	public void setDifficultyLevel(String difficultyLevel) {
		this.difficultyLevel = difficultyLevel;
	}
	public Set<McqOptions> getOptions() {
		return options;
	}
	public void setOptions(Set<McqOptions> options) {
		this.options = options;
	}
	
	public Test getTestId() {
		return testId;
	}
	public void setTestId(Test testId) {
		this.testId = testId;
	}

	
	

}
