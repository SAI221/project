package com.capgemini.otm.util;





import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;

@Component
public class JwtUtil {

	String TOKEN_SECRET="c3Vwcml5YQ==";

	public  String generatetoken(int userId) 
	{

		 
		 try {
		       	//to set algorithm
		       	Algorithm algorithm = Algorithm.HMAC256(TOKEN_SECRET);
		       	
		       	//payload
		       	String token = JWT.create()
		       	.withClaim("userId", userId)
		       	.sign(algorithm);
		       	return token;
		       	
		       	} catch (JWTCreationException exception) {
		        exception.printStackTrace();
		           //log Token Signing Failed
		       	}
		return null;
		      
		 }



	public int  decodetoken(String token) 
	{
		 int userName;
	    //for verification algorithm
	    com.auth0.jwt.interfaces.Verification verification=JWT.require(Algorithm.HMAC256(TOKEN_SECRET));
	    JWTVerifier jwtverifier=verification.build();
	    // decode token
	    DecodedJWT decodedjwt=jwtverifier.verify(token);
	    //retrive data
	    Claim claim=decodedjwt.getClaim("userId");
	    userName=claim.asInt();  
	    return userName;

		
	}

	
	


}
