package com.capgemini.otm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.otm.entity.Question;

@Repository
public interface QuestionRepo extends JpaRepository<Question, Long>{
	
public List<Question> findBySubjectAndDifficultyLevel(String subject, String difficultyLevel);

public Question findByQuestionId(int qId);
}
