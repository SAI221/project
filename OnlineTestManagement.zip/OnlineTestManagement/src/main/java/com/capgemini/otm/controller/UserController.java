package com.capgemini.otm.controller;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.otm.entity.Login;
import com.capgemini.otm.entity.Question;
import com.capgemini.otm.entity.Test;
import com.capgemini.otm.entity.User;
import com.capgemini.otm.repository.UserRepo;
import com.capgemini.otm.service.UserService;
import com.capgemini.otm.serviceImpl.UserServiceImpl;
import com.capgemini.otm.util.JwtUtil;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*") 
public class UserController {
	
	@Autowired
	private UserService userService;
	@Autowired
	private UserRepo repo;
	@Autowired
	private JwtUtil utility;
	
	@Autowired
	private UserServiceImpl service;
	
	
	@PostMapping("/add")
	public String addUser(@RequestBody User user) {
		
		return userService.addUser(user);
		
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody Login login,HttpServletRequest request,HttpServletResponse response) {
		User user = userService.login(login);
		if (user != null) {
			String token = utility.generatetoken(user.getUserId());

			response.setHeader("token", token);
			response.addHeader("Access-Control-Allow-Headers", "*");
			response.addHeader("Access-Control-Expose-Headers", "*");
			return new ResponseEntity<>(HttpStatus.OK);
			
		} else
			return new ResponseEntity<String>("{Invalid Credentials}", HttpStatus.BAD_REQUEST);
//		return userService.login(login,response);
	}
	@GetMapping("/check")
	public int check(HttpServletRequest request) {
		String token=request.getHeader("token");
		System.out.println(token);
		int id = utility.decodetoken(token);
		Optional<User> user = repo.findByUserId(id);
		System.out.println(user.get().getEmail());
		System.out.println(user.get().getType());
		return user.get().getType();
	}
	@PostMapping("/question")
	public Question addQuestion(@RequestBody Question question,@RequestHeader String token) {
		return userService.addQuestion(question, token);
		
	}
	
	@PostMapping("/test/{token}")
	public Test test(@RequestBody Test test,@PathVariable String token) {
		
		return service.Example(test,token);
		
	}
	
	
	@GetMapping("/test/{subject}/{difficultyLevel}")
	public List<Question> takeTest(@PathVariable String subject,@PathVariable String difficultyLevel,@RequestHeader String token) {
		return userService.getTest(subject,difficultyLevel,token);
	}
	
	
	
	
@GetMapping("/test1/{subject}/{difficultyLevel}")
public Set<Question> questions(HttpServletRequest request,@PathVariable String subject,@PathVariable String difficultyLevel){
	return userService.takeTest(subject, difficultyLevel, request.getHeader("token"));
}

@GetMapping(value = "/testList", produces = MediaType.APPLICATION_JSON_VALUE)
public List<Test> testList() {
	return userService.getTests();
}

@GetMapping(value="/viewtest/{testId}")
public Set<Question> viewTest( @PathVariable int testId){
	
	return userService.viewTest(testId);
	
}
@GetMapping(value="/question")
public List<Question> showQuestionList(){
	return userService.showQuestionList();
}

@DeleteMapping(value="/question/{qId}")
	public String deleteQuestion(@PathVariable int qId) {
	return userService.deleteQuestion(qId);
}
@PutMapping("/update/{testId}")
public User updateUser(@PathVariable int testId,HttpServletRequest request) {
	return userService.updateUser(testId,request.getHeader("token"));
}
}
