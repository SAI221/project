package com.capgemini.otm.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.otm.entity.Test;

@Repository
public interface TestRepo extends JpaRepository<Test, Long>{
public List<Test> findBySubjectAndDifficultyLevel(String subject,String difficultyLevel);

public Optional<Test> findByTestId   (int testId);
}
