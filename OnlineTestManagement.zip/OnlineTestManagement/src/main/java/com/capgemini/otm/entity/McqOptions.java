package com.capgemini.otm.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class McqOptions {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int OptId;
	
	private String optionText;
	
	private boolean type;
	
	@ManyToOne @JsonIgnore
	private Question questionId;
	
	public int getOptId() {
		return OptId;
	}
	public void setOptId(int optId) {
		OptId = optId;
	}
	public String getOptionText() {
		return optionText;
	}
	public void setOptionText(String optionText) {
		this.optionText = optionText;
	}
	public boolean isType() {
		return type;
	}
	public void setType(boolean type) {
		this.type = type;
	}
	
	public Question getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Question questionId) {
		this.questionId = questionId;
	}

	
}
