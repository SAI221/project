package com.capgemini.otm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.otm.entity.McqOptions;

@Repository
public interface McqOptionsRepo extends JpaRepository<McqOptions, Long> {

}
