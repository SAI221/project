package ExceptionHandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

public class CustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler{
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorMessage> generalException(Exception e) throws Exception {
		ErrorMessage errorDetails = new ErrorMessage();
		errorDetails.setMessage(e.getMessage());
		

		System.out.println(errorDetails);

		return new ResponseEntity<ErrorMessage>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	

}
