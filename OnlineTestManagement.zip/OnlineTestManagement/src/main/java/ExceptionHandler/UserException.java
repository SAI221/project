package ExceptionHandler;

public class UserException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	 int code;
	 String msg;
	 String details;
	 public UserException(int i, String msg, String string)
	 {
		super(msg);
	 }
	 
	 public UserException(String details, String msg)
	 {
		super(msg);
		
		 this.msg=msg;
		 this.details =details;
	 }	
}
