import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';
import { Question } from 'src/app/Model/question';
import { Observable } from 'rxjs';
import { UserServiceService } from 'src/app/Service/user-service.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss']
})
export class TestComponent implements OnInit {
  //questions: Observable<Question[]>;
   questions:any;
   config: any;
   count:number=0;
  // questionsList:Question[];
  form:FormGroup;
  constructor(private router:Router, private service :AdminService,private userService:UserServiceService, private formBuilder: FormBuilder) {
    this.config = {
      itemsPerPage:1,
      currentPage: 1,
      totalItems: this.questions    };
      
   }

  ngOnInit() {
    this.loadData();
  }
loadData(){
  console.log("list");
 
   this.userService.takeTest().subscribe(res => {this.questions=res;
    console.log(this.questions);
 
  console.log("abc")
  if(this.questions!=null){
  const mapped = Object.keys(this.questions).map(key => ({type: key, value: this.questions[key]}));
  console.log(mapped);
 
  }
  else{
    alert("No Test Found For This User!!!")
    localStorage.removeItem('token');
    this.router.navigate(['/home']);
  }
}, (error) => console.error("No Test Found"));

}
pageChanged(event){
  this.config.currentPage = event;
}
showResult(){
  console.log("gfdjh")
  
alert("Your Score is : "+this.count);
this.userService.updateTest();
this.router.navigate(['/homepage'])
}
answerCheck(answer:string ,Question:Question){

  console.log(answer);
  console.log(Question.answer)
  if(Question.answer===answer){
    this.count=this.count+1;
    console.log(this.count);
  }
  else {

    this.count=this.count;
    console.log(this.count)
  }

}
}
