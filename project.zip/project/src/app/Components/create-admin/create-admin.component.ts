import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/Service/admin.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-create-admin',
  templateUrl: './create-admin.component.html',
  styleUrls: ['./create-admin.component.scss']
})
export class CreateAdminComponent implements OnInit {
  
  registerForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder,private service:AdminService,
    private router:Router) { }

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
    
         name:['',[Validators.required]],
        emailId: ['', [Validators.required, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$'),Validators.email,Validators.email]],
          password: ['', [Validators.required, Validators.minLength(6)]],
         
      });
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }
  save(){
    this.service.createAdmin(this.registerForm.value)
    .subscribe(data => console.log(data), error => console.log(error));
 
  }
  onSubmit() {
      this.submitted = true;

      // stop here if form is invalid
      if (this.registerForm.valid) {
  
        this.save();
        alert('SUCESS!! :-)');
        this.router.navigate(['/adminLogin']);
      }
      else{alert('Fail!! :-(');}
    
  }
}



