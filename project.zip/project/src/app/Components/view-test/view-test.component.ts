import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';
import { UserServiceService } from 'src/app/Service/user-service.service';
import { Question } from 'src/app/Model/question';

@Component({
  selector: 'app-view-test',
  templateUrl: './view-test.component.html',
  styleUrls: ['./view-test.component.scss']
})
export class ViewTestComponent implements OnInit {

  questions:any;
   config: any;
   count:number=0;
   testId:number;
   questionId:number;
   questionsList:Array<any>;

  form:FormGroup;
  constructor(private router:Router, private service :AdminService,private userService:UserServiceService, private formBuilder: FormBuilder) {
    this.config = {
      itemsPerPage:2,
      currentPage: 1,
      totalItems: this.questions    };
      
   }

  ngOnInit() {
    this.loadData();
    this.questionList();
   
   
  }
loadData(){
  console.log("list");
  this.testId= +localStorage.getItem("testId");
 
 console.log(localStorage.getItem("testId"));
//  this.service.veiwTest(this.testId).subscribe(this.questions)
   this.service.veiwTest(this.testId).subscribe(res => {this.questions=res;
    console.log(this.questions);
 
  console.log("abc")
  if(this.questions!=null){
  const mapped = Object.keys(this.questions).map(key => ({type: key, value: this.questions[key]}));
  console.log(mapped);
 
  }
  
});

}
pageChanged(event){
  this.config.currentPage = event;
}

// addQuestion(questionId:number){

// this.testId= +localStorage.getItem("testId");
// this.service.addQuestion(questionId,this.testId);
// }
addQuestion(event:any){
  console.log(event)
  this.questionId = event.target.value;
  // console.log(this.testId);
  this.service.addQuestion(this.questionId,this.testId).subscribe(res=>{
   
  });
  this.loadData();
  
 }
 questionList(){
  this.service.questionList().subscribe(data=>{
    console.log(data);
    this.questionsList=data});
   console.log("qu"+this.questionsList);
}

deleteQuestion(questionId:number){
  console.log("entered");
  this.testId =+ localStorage.getItem("testId");
  // this.service.deleteQuestionFromTest(questionId,this.testId);
  this.service.deleteQuestionFromTest(questionId,this.testId).subscribe(res=>{
    alert("Deleted Sucessfully");
    console.log(questionId)
  })
  
  this.loadData();
}
}