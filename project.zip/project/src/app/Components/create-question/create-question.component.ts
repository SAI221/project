import { Component, OnInit } from '@angular/core';
import { Question } from 'src/app/Model/question';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-create-question',
  templateUrl: './create-question.component.html',
  styleUrls: ['./create-question.component.scss']
})
export class CreateQuestionComponent implements OnInit {
  questionform: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder,private service:AdminService,
    private router:Router) { }

  ngOnInit() {
      this.questionform = this.formBuilder.group({
    
         question:['',[Validators.required]],
        answer: ['', [Validators.required]],
          option1: ['', [Validators.required]],
          option2: ['', [Validators.required]],
          option3: ['', [Validators.required]],
          option4: ['', [Validators.required]],
          

         
      });
  }

  // convenience getter for easy access to form fields
  get f() { return this.questionform.controls; }
  save(){
    this.service.createQuestion(this.questionform.value)
    .subscribe(data => console.log(data), error => console.log(error));
 
  }
  onSubmit() {
      this.submitted = true;

      // stop here if form is invalid
      if (this.questionform.valid) {
  
        this.save();
        alert('SUCESS!! :-)');
        this.router.navigate(['/questionList']);
      }
      else{alert('Failed!! :-(');}
    
  }
}
//   question: Question = new Question();
//   loading = false;
//   submitted = false;
//   constructor(private router: Router, private service: AdminService) { }

//   ngOnInit() {
//   }

//   newQuestion(): void {
//     this.submitted = false;
//     this.question= new Question();
//   }

//   onSubmit() {
//     this.submitted = true;
//     this.save();
//   }

//   save() {
//     this.service.createQuestion(this.question).subscribe(data => console.log(data), error => console.log(error));
//     this.question= new Question();
//   }
// }

