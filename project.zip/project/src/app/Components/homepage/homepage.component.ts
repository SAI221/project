import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';
import { UserServiceService } from 'src/app/Service/user-service.service';
import { Question } from 'src/app/Model/question';


@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.scss']
})
export class HomepageComponent implements OnInit {
 
  constructor(private router:Router) { }

  ngOnInit() {
  }
  logOut(){
    localStorage.removeItem('token');
    this.router.navigate(['/home']);
  }

}

