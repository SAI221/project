import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  //private LOGO = require("./assets/Images/Online-Test_2.jpg");
  constructor() { }

  ngOnInit() {
    localStorage.removeItem("token");
  }

}
