import { Component, OnInit } from '@angular/core';
import { Admin } from 'src/app/Model/admin';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';
import { Login } from 'src/app/Model/login';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.scss']
})
export class AdminLoginComponent implements OnInit {
//   loginform: FormGroup;
//   submitted = false;

//   constructor(private formBuilder: FormBuilder,private service:AdminService,
//     private router:Router) { }

//   ngOnInit() {
//       this.loginform = this.formBuilder.group({
//         //  userName: ['', Validators.required],
         
//         emailId: ['', [Validators.required, Validators.email]],
//           password: ['', [Validators.required, Validators.minLength(6)]],
         
//       });
//   }

//   // convenience getter for easy access to form fields
//   get f() { return this.loginform.controls; }
//   save(){
//     this.service.adminLogin(this.loginform.value)
//     .subscribe(data => {
//       alert('SUCESS!! :-)');
//       this.router.navigate(['/admin']);
//       console.log(data), error => console.log(error)});
 
//   }
//   onSubmit() {
//       this.submitted = true;

//       // stop here if form is invalid
//       if (this.loginform.valid) {
//         // this.service.createUser(this.registerForm.value);
//         this.save();
       
//       }
//       else{alert('Invalid User! :-(');}
//       //  
//       //  \n\n' + JSON.stringify(this.registerForm.value))
//   }
// }
  login: Login;
  emailId: any;
  password: any;
  constructor(private router: Router, private service: AdminService) {
    this.login = new Login();
    this.emailId = this.login.email
    this.password = this.login.password;
  }

  ngOnInit() {
    
  }


  getAdmin() {
    this.service.adminLogin(this.login).subscribe(res => {
      localStorage.setItem('token', res.headers.get('token'));
      console.log(res.headers.get('token'));
      if (localStorage.getItem('token') != null) {
        this.router.navigate(['/admin']);
        alert('login successfully !...')
      }
      else{alert('Invalid Credentials')}
    },
     (error) => {console.error(error);
      alert('Invalid Credentials');})
  }
  logOut(){
    localStorage.removeItem('token');
    this.router.navigate(['/home']);
  }
}



