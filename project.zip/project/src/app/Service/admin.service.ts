import { Injectable } from '@angular/core';

import { Admin } from '../Model/admin';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Login } from '../Model/login';
import { Test } from '../Model/test';
import { Question } from '../Model/question';
import { QuestionsComponent } from '../Components/questions/questions.component';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private baseUrl = 'http://localhost:8293/admin'
  admin: Admin = new Admin();
  constructor(private http: HttpClient) { }
  private httpheaders = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      token: localStorage.getItem('token')
    })
  };
  createAdmin(admin: Admin) {
    return this.http.post(this.baseUrl + '/create', admin);
  }
  adminLogin(login: Login): Observable<any> {
    return this.http.post<any>(this.baseUrl + '/login', login, { observe: 'response' });
  }

  testList(): Observable<any> {
    return this.http.get<Test[]>(this.baseUrl + '/testList');
  }
  getTest(testId: number):Observable<Question[]> {
    return this.http.get<Question[]>(`${this.baseUrl}/test/${testId}`);
  }
  createTest(test: Test) {
    return this.http.post(this.baseUrl + '/test', test);
  }
  createQuestion(question:Question){
    return this.http.post(this.baseUrl+'/question',question,this.httpheaders);
  }
  questionList(): Observable<Question[]> {
    return this.http.get<Question[]>(this.baseUrl + '/question');
  }
  deleteTest(testId:number){
    return this.http.delete(`${this.baseUrl}/test/${testId}`);
  }
  deleteQuestion(questionId:number){
    return this.http.delete(`${this.baseUrl}/question/${questionId}`,this.httpheaders);
  }
  assignTest(userId:number,testId:number){
    return this.http.put(`${this.baseUrl}/test1/${userId}/${testId}`,this.httpheaders);
  }
  veiwTest(testId: number):Observable<Question[]>{
    return this.http.get<Question[]>(`${this.baseUrl}/test/${testId}`);
  }
addQuestion(questionId:number,testId:number){
  return this.http.post(`${this.baseUrl}/question/${questionId}/${testId}`,this.httpheaders);
}
deleteQuestionFromTest(questionId:number,testId:number){
  return this.http.delete(`${this.baseUrl}/question/${questionId}/${testId}`,this.httpheaders);
}
}
