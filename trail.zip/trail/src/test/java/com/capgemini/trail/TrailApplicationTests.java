package com.capgemini.trail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrailApplicationTests {

	@Test
	void contextLoads() {
	}

}
