package com.capgemini.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.entity.Admin;
import com.capgemini.entity.Login;

public interface AdminRepo extends JpaRepository<Admin, Long> {

	Optional<Admin> findByEmailIdAndPassword(Login login);

	Optional<Admin> findByEmailId(String email);

}
