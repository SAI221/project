package com.capgemini.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.Login;
import com.capgemini.entity.User;
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	
	public Optional<User> findByUserEmailAndPassword(Login login);

	public User findByUserEmail(String email);

	public Optional<User> findByUserId(int userId);

}
