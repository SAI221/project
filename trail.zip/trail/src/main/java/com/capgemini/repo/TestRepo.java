package com.capgemini.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.entity.Test;

public interface TestRepo extends JpaRepository<Test, Long>{

}
