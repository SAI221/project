package com.capgemini.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.entity.Question;

public interface QuestionRepo extends JpaRepository<Question, Long>{

	Question findByQId(int qId);

	List<Question> findByTestId(int testId);
	


}
