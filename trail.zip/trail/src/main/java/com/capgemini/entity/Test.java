package com.capgemini.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Test {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int testId;

private int noOfQuestions;

public int getNoOfQuestions() {
	return noOfQuestions;
}

public void setNoOfQuestions(int noOfQuestions) {
	this.noOfQuestions = noOfQuestions;
}

@OneToMany(cascade=CascadeType.ALL)
private List<Question> questionList=new ArrayList<Question>();

@OneToOne(cascade=CascadeType.ALL)
private int adminId;

public int getTestId() {
	return testId;
}

public void setTestId(int testId) {
	this.testId = testId;
}

public List<Question> getQuestionList() {
	return questionList;
}

public void setQuestionList(List<Question> questionList) {
	this.questionList = questionList;
}

public int getAdminId() {
	return adminId;
}

public void setAdminId(int adminId) {
	this.adminId = adminId;
}

@Override
public String toString() {
	return "Test [testId=" + testId + ", questionList=" + questionList + ", adminId=" + adminId + "]";
}


	
}
