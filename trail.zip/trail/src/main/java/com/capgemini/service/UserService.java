package com.capgemini.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.entity.Login;
import com.capgemini.entity.Question;
import com.capgemini.entity.User;

@Service
public interface UserService {

	public String createUser(User user);

	public String userLogin(Login login);

	public List<Question> takeTest(String token);
}
