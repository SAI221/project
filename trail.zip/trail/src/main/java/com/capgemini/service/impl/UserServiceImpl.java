package com.capgemini.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.entity.Login;
import com.capgemini.entity.Question;
import com.capgemini.entity.User;
import com.capgemini.repo.QuestionRepo;
import com.capgemini.repo.UserRepository;
import com.capgemini.service.UserService;
import com.capgemini.utility.Util;

public class UserServiceImpl implements UserService {
	
	@Autowired 
	private UserRepository userRepo;
	
	@Autowired
	private QuestionRepo questionRepo;
	
	@Autowired
	private Util util;
	@Override
	public String createUser(User user) {
		userRepo.save(user);
		return "Added User";
	}

	@Override
	public String userLogin(Login login) {
		Optional<User> user=userRepo.findByUserEmailAndPassword(login);
		if (user.isPresent()) {
		String token=	util.generatetoken(login.getEmail());
		System.out.println("token for user is"+token);
			return "login successfully";
		}
		return "Invalid User:";
	}

	@Override
	public List<Question> takeTest(String token) {
		String email=util.decodetoken(token);
		User user=userRepo.findByUserEmail(email);
		
		int testId=user.getTest();
		List<Question> test=questionRepo.findByTestId(testId);
		return test;
	}
	
}
