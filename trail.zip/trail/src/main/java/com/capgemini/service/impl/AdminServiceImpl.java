package com.capgemini.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.entity.Admin;
import com.capgemini.entity.Login;
import com.capgemini.entity.Question;
import com.capgemini.entity.Test;
import com.capgemini.entity.User;
import com.capgemini.repo.AdminRepo;
import com.capgemini.repo.QuestionRepo;
import com.capgemini.repo.TestRepo;
import com.capgemini.repo.UserRepository;
import com.capgemini.service.AdminService;
import com.capgemini.utility.Util;

public class AdminServiceImpl implements AdminService {
	
	@Autowired
	private AdminRepo adminRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private QuestionRepo questionRepo;
	
	@Autowired
	private TestRepo testRepo;
	
	@Autowired
	private Util util;

	@Override
	public String addAdmin(Admin admin) {
		adminRepo.save(admin);
		return "Added Successfully";
	}

	@Override
	public String addQuestion(Question question,String token) {
	String email=	util.decodetoken(token);
		Optional<Admin> admin= adminRepo.findByEmailId(email);
		if (admin.isPresent()) {
			questionRepo.save(question);
			return "Added Successfully";
		}
		return "Unauthorized user";
		
		
	}

	@Override
	public String deleteQuestion(int qId,String token) {
		String email=	util.decodetoken(token);
		Optional<Admin> admin= adminRepo.findByEmailId(email);
		if (admin.isPresent()) {
		Question question=questionRepo.findByQId(qId);
		questionRepo.delete(question);
		return "Deleted";
		}
		return "Unauthorized user";
	}

	@Override
	public String assignTest(int userId, int testId,String token) {
		String email=	util.decodetoken(token);
		Optional<Admin> admin= adminRepo.findByEmailId(email);
		if (admin.isPresent()) {
		Optional<User> user=userRepo.findByUserId(userId);
		user.get().setTest(testId);
		return "Assigned Test";
		}
		return "Unauthorized user";
	}

	@Override
	public String adminLogin(Login login) {
		Optional<Admin> admin=adminRepo.findByEmailIdAndPassword(login);
		if (admin.isPresent()) {
		String token=	util.generatetoken(login.getEmail());
		System.out.println("token for user is"+token);
			return "login successfully";
		}
		return "Invalid User:";
	}

	@Override
	public String addNewTest(Test test) {
		List<Question> list= questionRepo.findAll();
		List<Question> questionListInTest= new ArrayList<Question>();
		Random rand = new Random();
		for(int i=0;i<test.getNoOfQuestions();i++) {
			int randomIndex = rand.nextInt(list.size());
	        Question randomElement = list.get(randomIndex);
	        questionListInTest.add(randomElement);
		}
		test.setQuestionList(questionListInTest);
		testRepo.save(test);
		return null;
	}

}
