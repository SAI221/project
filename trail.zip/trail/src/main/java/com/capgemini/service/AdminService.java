package com.capgemini.service;

import com.capgemini.entity.Admin;
import com.capgemini.entity.Login;
import com.capgemini.entity.Question;
import com.capgemini.entity.Test;

public interface AdminService {

	String addAdmin(Admin admin);

	String addQuestion(Question question, String token);

	String deleteQuestion(int qId, String token);

	String assignTest(int userId, int testId, String token);

	String adminLogin(Login login);

	String addNewTest(Test test);

}
