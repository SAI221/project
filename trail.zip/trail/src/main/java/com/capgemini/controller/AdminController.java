package com.capgemini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.entity.Admin;
import com.capgemini.entity.Login;
import com.capgemini.entity.Question;
import com.capgemini.entity.Test;
import com.capgemini.service.AdminService;

@RestController
public class AdminController {

	@Autowired 
	private AdminService adminService;
	
	@GetMapping("/adminLogin")
	public String userLogin(@RequestBody Login login) {
		
		return adminService.adminLogin(login);
		
	}
	
	@PostMapping("/createAdmin")
	public String createAdmin(@RequestBody Admin admin) {
		return adminService.addAdmin(admin);
		
	}
	
	@PostMapping("/addQuestion")
	public String createQuestion(@RequestBody Question question,@RequestHeader String token) {
		
		return adminService.addQuestion(question,token);
		
	}
	
	@PostMapping("/deleteQuestion/{qId}")
	public String deleteQuestion(@PathVariable int qId,@RequestHeader String token) {
		return adminService.deleteQuestion(qId,token);
	}
	
	@PutMapping("/assignTest/{userId}/{testId}")
	public String assignTestToUser(@PathVariable int userId,int testId,@RequestHeader String token) {
		return adminService.assignTest(userId,testId,token);
		}
	
	@PostMapping("/addTest")
	public String addTest(@RequestBody Test test) {
		return adminService.addNewTest(test);}
}
