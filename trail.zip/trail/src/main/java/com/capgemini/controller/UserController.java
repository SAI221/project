package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.entity.Login;
import com.capgemini.entity.Question;
import com.capgemini.entity.User;
import com.capgemini.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userService;
	
	@PostMapping("/create")
	public String createUser(@RequestBody User user) {
		
		return userService.createUser(user);
		
	}
	@GetMapping("/userLogin")
	public String userLogin(@RequestBody Login login) {
		
		return userService.userLogin(login);
		
	}
	
	@PostMapping("/takeTest")
	public List<Question> testForUser(@RequestHeader String token) {
		return userService.takeTest(token);
	}
	
}
