package com.capgemini.entity;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Test {
	@Id
	private int testId;

	private int noOfQuestions;

	public int getNoOfQuestions() {
		return noOfQuestions;
	}

	public void setNoOfQuestions(int noOfQuestions) {
		this.noOfQuestions = noOfQuestions;
	}

	// @JsonIgnore
	// @OneToMany(cascade=CascadeType.ALL,targetEntity=Questions.class )
	@ManyToMany
	@JoinTable(name = "addquestiontotest", joinColumns = @JoinColumn(name = "testId"), inverseJoinColumns = @JoinColumn(name = "questionId"))
	private Set<Questions> questionList;
	//
	// @OneToOne(cascade=CascadeType.ALL)
	// private int adminId;

	@Override
	public String toString() {
		return "Test [testId=" + testId + ", noOfQuestions=" + noOfQuestions + ", questionList=" + questionList + "]";
	}

	public Set<Questions> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(Set<Questions> questionList) {
		this.questionList = questionList;
	}

	public int getTestId() {
		return testId;
	}

	public void setTestId(int testId) {
		this.testId = testId;
	}

	// public List<Question> getQuestionList() {
	// return questionList;
	// }
	//
	// public void setQuestionList(List<Question> questionList) {
	// this.questionList = questionList;
	// }
	//
	// public int getAdminId() {
	// return adminId;
	// }
	//
	// public void setAdminId(int adminId) {
	// this.adminId = adminId;
	// }

	// @Override
	// public String toString() {
	// return "Test [testId=" + testId + ", questionList=" + questionList + ",
	// adminId=" + adminId + "]";
	// }

}
