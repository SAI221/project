package com.capgemini.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Admin")
public class Admin {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int adminId;
	private String name;
	@Column(name = "emailId", unique = true)
	private String emailId;
	private String password;
	//
	// @OneToMany(cascade=CascadeType.ALL)
	// private List<User> userList=new ArrayList<>();

	// public List<User> getUserList() {
	// return userList;
	// }
	// public void setUserList(List<User> userList) {
	// this.userList = userList;
	// }
	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", name=" + name + ", emailId=" + emailId + ", password=" + password + "]";
	}

}
