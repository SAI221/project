package com.capgemini.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.entity.Login;
import com.capgemini.entity.Questions;
import com.capgemini.entity.User;
import com.capgemini.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping(path = "/user", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<User> getAll() {
		return null;
	}

	@PostMapping("/create")
	public String createUser(@RequestBody User user) {
		return userService.createUser(user);
	}

	@GetMapping("/Login")
	public String userLogin(@RequestBody Login login) {
		return userService.userLogin(login);
	}

	@PostMapping("/test")
	public Set<Questions> testForUser(@RequestHeader String token) {
		return userService.takeTest(token);
	}

}
