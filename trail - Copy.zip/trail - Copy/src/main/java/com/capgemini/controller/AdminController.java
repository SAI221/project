package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.entity.Admin;
import com.capgemini.entity.Login;
import com.capgemini.entity.Questions;
import com.capgemini.entity.Test;
import com.capgemini.service.AdminService;

@RestController
public class AdminController {

	@Autowired
	private AdminService adminService;

	@GetMapping(path = "/admin/login", produces = MediaType.APPLICATION_JSON_VALUE)
	public String userLogin(@RequestBody Login login) {
		return adminService.adminLogin(login);
	}

	@PostMapping("/admin")
	public String createAdmin(@RequestBody Admin admin) {
		return adminService.addAdmin(admin);
	}

	@GetMapping("/question")
	public List<Questions> getQuestions() {
		return adminService.getQuestions();
	}

	@PostMapping("/question")
	public String createQuestion(@RequestBody Questions question, @RequestHeader String token) {
		return adminService.addQuestion(question, token);
	}

	@PostMapping("/question/{questionId}/{testId}")
	public String addQuestionToTest(@PathVariable int questionId, @PathVariable int testId,
			@RequestHeader String token) {
		return adminService.addQuestionToTest(questionId, testId, token);

	}

	@DeleteMapping("/question/{questionId}/{testId}")
	public String deleteQuestionFromTest(@PathVariable int questionId, @PathVariable int testId,
			@RequestHeader String token) {
		return adminService.deleteQuestionFromTest(questionId, testId, token);
	}

	@PutMapping("/question/{userId}/{testId}")
	public String assignTestToUser(@PathVariable int userId, @PathVariable int testId, @RequestHeader String token) {
		return adminService.assignTest(userId, testId, token);
	}

	@PostMapping("/test")
	public String addTest(@RequestBody Test test) {
		return adminService.addNewTest(test);
	}

}
