package com.capgemini.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.Questions;

@Repository
public interface QuestionRepo extends JpaRepository<Questions, Long> {

	public Questions findByQuestionId(int id);

}
