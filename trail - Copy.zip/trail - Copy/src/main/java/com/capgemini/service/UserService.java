package com.capgemini.service;

import java.util.List;
import java.util.Set;

import com.capgemini.entity.Login;
import com.capgemini.entity.Questions;
import com.capgemini.entity.User;

public interface UserService {

	public String createUser(User user);

	public String userLogin(Login login);

	public Set<Questions> takeTest(String token);

	public List<User> getAll();
}
