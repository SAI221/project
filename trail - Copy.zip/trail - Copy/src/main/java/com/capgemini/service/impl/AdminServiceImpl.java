package com.capgemini.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.entity.Admin;
import com.capgemini.entity.Login;
import com.capgemini.entity.Questions;
import com.capgemini.entity.Test;
import com.capgemini.entity.User;
import com.capgemini.repo.AdminRepo;
import com.capgemini.repo.QuestionRepo;
import com.capgemini.repo.TestRepo;
import com.capgemini.repo.UserRepository;
import com.capgemini.service.AdminService;
import com.capgemini.utility.Util;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminRepo adminRepo;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private QuestionRepo questionRepo;

	@Autowired
	private TestRepo testRepo;

	@Autowired
	private Util util;

	@Override
	public String addAdmin(Admin admin) {
		adminRepo.save(admin);
		return "Added Successfully";
	}

	@Override
	public String addQuestion(Questions question, String token) {
		String email = util.decodetoken(token);
		Optional<Admin> admin = adminRepo.findByEmailId(email);
		if (admin.isPresent()) {
			questionRepo.save(question);
			return "Added Successfully";
		}
		return "Unauthorized user";

	}

	@Override
	public String deleteQuestion(int qId, String token) {
		String email = util.decodetoken(token);
		Optional<Admin> admin = adminRepo.findByEmailId(email);
		if (admin.isPresent()) {
			Questions question = questionRepo.findByQuestionId(qId);
			questionRepo.delete(question);
			return "Deleted";
		}
		return "Unauthorized user";
	}

	@Override
	public String assignTest(int userId, int testId, String token) {
		String email = util.decodetoken(token);
		Optional<Admin> admin = adminRepo.findByEmailId(email);
		if (admin.isPresent()) {
			// Optional<User> user=userRepo.findByUserId(userId);
			Optional<User> user = userRepo.findByUserIdAndTest(userId, testId);
			if (user.isPresent()) {
				return "user is already have a test";
			} else {
				user.get().setTest(testId);
				userRepo.save(user.get());
				return "Assigned Test";
			}
		}
		return "Unauthorized user";
	}

	@Override
	public String adminLogin(Login login) {
		Optional<Admin> admin = adminRepo.findByEmailIdAndPassword(login.getEmail(), login.getPassword());
		if (admin.isPresent()) {
			String token = util.generatetoken(login.getEmail());
			System.out.println("token for user is" + token);
			return "login successfully";
		}
		return "Invalid User:";
	}

	@Override
	public String addNewTest(Test test) {
		List<Questions> list = questionRepo.findAll();
		for (Questions questions : list) {
			System.out.println(questions);
		}
		System.out.println("inside new test");
		Set<Questions> questionListInTest = new HashSet<Questions>();
		Random rand = new Random();
		for (int i = 0; i < test.getNoOfQuestions(); i++) {
			int randomIndex = rand.nextInt(list.size());
			System.out.println(randomIndex);
			Questions randomElement = list.get(randomIndex);
			System.out.println(randomElement + "xxxxx");
			questionListInTest.add(randomElement);
			System.out.println(questionListInTest);
		}
		test.setQuestionList(questionListInTest);
		testRepo.save(test);
		return null;
	}

	@Override
	public List<Questions> getQuestions() {
		List<Questions> qList = questionRepo.findAll();
		return qList;
	}

	@Override
	public String addQuestionToTest(int id, int testId, String token) {
		Test test = testRepo.findByTestId(testId);
		Set<Questions> questionListInTest = test.getQuestionList();
		Questions question = questionRepo.findByQuestionId(id);
		questionListInTest.add(question);
		test.setQuestionList(questionListInTest);
		test.setNoOfQuestions(questionListInTest.size());
		testRepo.save(test);
		return "Added";
	}

	@Override
	public String deleteQuestionFromTest(int questionId, int testId, String token) {
		Test test = testRepo.findByTestId(testId);
		Set<Questions> qList = test.getQuestionList();
		Questions question = questionRepo.findByQuestionId(questionId);
		qList.remove(question);
		test.setQuestionList(qList);
		test.setNoOfQuestions(qList.size());
		testRepo.save(test);
		return "Deleted";

	}

}
