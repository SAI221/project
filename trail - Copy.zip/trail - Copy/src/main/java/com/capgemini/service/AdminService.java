package com.capgemini.service;

import java.util.List;

import com.capgemini.entity.Admin;
import com.capgemini.entity.Login;
import com.capgemini.entity.Questions;
import com.capgemini.entity.Test;

public interface AdminService {

	String addAdmin(Admin admin);

	String addQuestion(Questions question, String token);

	String deleteQuestion(int qId, String token);

	String assignTest(int userId, int testId, String token);

	String adminLogin(Login login);

	String addNewTest(Test test);

	List<Questions> getQuestions();

	String addQuestionToTest(int id, int testId, String token);

	String deleteQuestionFromTest(int questionId, int testId, String token);

}
