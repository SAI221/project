package com.capgemini.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.entity.Login;
import com.capgemini.entity.Questions;
import com.capgemini.entity.User;
import com.capgemini.repo.TestRepo;
import com.capgemini.repo.UserRepository;
import com.capgemini.service.UserService;
import com.capgemini.utility.Util;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired 
	private UserRepository userRepo;
	
	@Autowired
	private TestRepo testRepo;
	
	@Autowired
	private Util util;
	@Override
	public String createUser(User user) {
		userRepo.save(user);
		return "Added User";
	}

	
	
	@Override
	public String userLogin(Login login) {
		Optional<User> user=userRepo.findByUserEmailAndPassword(login.getEmail(),login.getPassword());
		if (user.isPresent()) {
		String token=	util.generatetoken(login.getEmail());
		System.out.println("token for user is"+token);
			return "login successfully";
		}
		return "Invalid User:";
	}

	@Override
	public Set<Questions> takeTest(String token) {
		String email=util.decodetoken(token);
		User user=userRepo.findByUserEmail(email);
		
		int testId=user.getTest();
//		List<Questions> test=questionRepo.findByTestId(testId);
		Set<Questions> test=testRepo.findByTestId(testId).getQuestionList();
		return test;
	}



	@Override
	public List<User> getAll() {
		// TODO Auto-generated method stub
		return userRepo.findAll();
	}
	
}
