package com.capgemini.trail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.context.SpringBootTest;

@EnableAutoConfiguration
@EntityScan(basePackages = {"com.capgemini.entity"}) 
@SpringBootTest
class TrailApplicationTests {

	@Test
	void contextLoads() {
	}

}
